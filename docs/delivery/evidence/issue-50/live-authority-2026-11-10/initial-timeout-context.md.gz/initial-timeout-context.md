# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: product-behaviours.spec.mjs >> live action authority explains unavailable dependencies without granting a write
- Location: tests/e2e/product-behaviours.spec.mjs:80:1

# Error details

```
TimeoutError: page.waitForResponse: Timeout 15000ms exceeded while waiting for event "response"
```

# Test source

```ts
  1   | import { test as base, expect } from '@playwright/test';
  2   | import { readFile } from 'node:fs/promises';
  3   | 
  4   | const repository = process.env.LCC_E2E_REPOSITORY;
  5   | const issue = Number(process.env.LCC_E2E_ISSUE);
  6   | if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository ?? '') || !Number.isSafeInteger(issue) || issue < 1)
  7   |   throw Error('Explicit LCC_E2E_REPOSITORY and positive LCC_E2E_ISSUE are required.');
  8   | const origin = process.env.LCC_E2E_ORIGIN;
  9   | const issuePath = '/workspace/issues/' + repository + '/' + issue;
  10  | const controlsPath = '/api/issues/' + repository + '/' + issue + '/controls';
  11  | 
  12  | const test = base.extend({
  13  |   owner: [async ({ browser }, use) => {
  14  |     if (!process.env.LCC_E2E_REALM_FILE || !process.env.LCC_E2E_USER) throw Error('Explicit development realm file and user are required.');
  15  |     const realm = JSON.parse(await readFile(process.env.LCC_E2E_REALM_FILE, 'utf8'));
  16  |     const user = realm.users?.find(value => value.username === process.env.LCC_E2E_USER);
  17  |     const password = user?.credentials?.find(value => value.type === 'password')?.value;
  18  |     if (!password) throw Error('Selected development test user is unavailable.');
  19  |     const context = await browser.newContext({ baseURL: origin, ignoreHTTPSErrors: false });
  20  |     const page = await context.newPage();
  21  |     try {
  22  |       try {
  23  |         await page.goto('/');
  24  |         await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  25  |         await page.locator('#username').fill(user.username);
  26  |         await page.locator('#password').fill(password);
  27  |         await page.locator('#kc-login').click();
  28  |         await page.waitForURL(url => url.origin === new URL(origin).origin && !url.pathname.startsWith('/signin'));
  29  |         expect((await context.request.get('/api/session')).status()).toBe(200);
  30  |       } catch { throw Error('Trusted development sign-in failed; login data and traces are intentionally not retained.'); }
  31  |       await page.close();
  32  |       await use(context);
  33  |     } finally { await context.close(); }
  34  |   }, { scope: 'worker' }],
  35  |   signedPage: async ({ owner }, use) => {
  36  |     const page = await owner.newPage();
  37  |     await use(page);
  38  |     await page.close();
  39  |   },
  40  | });
  41  | 
  42  | test('live repository discovery preserves source identity and collection coverage', async ({ signedPage: page }, info) => {
  43  |   await page.goto('/workspace/repositories');
  44  |   const repositoryLink = page.getByRole('link', { name: repository, exact: true });
  45  |   await expect(repositoryLink).toBeVisible();
  46  |   await repositoryLink.click();
  47  |   await expect(page).toHaveURL(url => url.pathname === '/workspace/repositories/' + repository);
  48  |   await expect(page.locator('.factory-issue').first()).toBeVisible();
  49  |   await expect(page.locator('#factory-count')).toContainText('issues');
  50  |   await expect(page.locator('#factory-projects')).toContainText('coverage');
  51  |   const source = await page.request.get('/api/factory/' + repository + '?number=' + issue);
  52  |   expect(source.status()).toBe(200);
  53  |   const exact = await source.json();
  54  |   expect(exact.availability).toBe('available');
  55  |   expect(exact.issues).toHaveLength(1);
  56  |   expect(exact.issues[0].number).toBe(issue);
  57  |   expect(exact.issues[0].sourceUrl).toBe('https://github.com/' + repository + '/issues/' + issue);
  58  |   await page.screenshot({ path: info.outputPath('repository.png') });
  59  | });
  60  | 
  61  | test('live issue context retains actual description conversation and source provenance', async ({ signedPage: page }, info) => {
  62  |   const response = await page.request.get('/api/issues/' + repository + '/' + issue);
  63  |   expect(response.status()).toBe(200);
  64  |   const source = await response.json();
  65  |   expect(source.availability).toBe('available');
  66  |   expect(source.issue.number).toBe(issue);
  67  |   await page.goto(issuePath);
  68  |   await expect(page.locator('#issue-title')).toHaveText(source.issue.title);
  69  |   await expect(page.locator('#issue-body')).not.toBeEmpty();
  70  |   await expect(page.locator('#conversation-coverage')).toContainText('Source');
  71  |   await expect(page.locator('#issue-comments > li')).toHaveCount(source.conversation.items.length);
  72  |   await expect(page.locator('#controls-status')).not.toHaveText(/^(Checking|Refreshing)/i);
  73  |   await page.screenshot({ path: info.outputPath('issue.png') });
  74  |   await page.setViewportSize({ width: 390, height: 844 });
  75  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  76  |   await expect(page.locator('.header-identity strong')).not.toBeEmpty();
  77  |   await page.screenshot({ path: info.outputPath('issue-narrow.png') });
  78  | });
  79  | 
  80  | test('live action authority explains unavailable dependencies without granting a write', async ({ signedPage: page }, info) => {
> 81  |   const observation = page.waitForResponse(response => new URL(response.url()).pathname === controlsPath && response.request().method() === 'GET');
      |                            ^ TimeoutError: page.waitForResponse: Timeout 15000ms exceeded while waiting for event "response"
  82  |   await page.goto(issuePath);
  83  |   const source = await (await observation).json();
  84  |   await expect(page.locator('#controls-status')).not.toHaveText(/^(Checking|Refreshing)/i);
  85  |   if (source.availability === 'available' && typeof source.facts?.actor?.login === 'string' && source.facts.actor.login.trim()) {
  86  |     await expect(page.locator('.header-identity strong')).toHaveText(source.facts.actor.login.trim());
  87  |   }
  88  |   if (source.availability === 'available' && source.submissionAvailable === true && source.facts?.actions?.comment?.eligible === true) {
  89  |     await expect(page.getByLabel('Your comment or answer')).toBeVisible();
  90  |     await expect(page.getByRole('button', { name: 'Review comment', exact: true })).toBeEnabled();
  91  |   }
  92  |   const blocked = source.availability !== 'available' || Object.values(source.facts?.actions ?? {}).some(action => !action.eligible);
  93  |   test.skip(!blocked, 'This configured source has no unavailable action prerequisite; the negative example needs another scope.');
  94  |   await expect(page.locator('#control-actions button:disabled').first()).toBeVisible();
  95  |   await expect(page.locator('#mission-actions')).toContainText(/unavailable|permission|authority|supported/i);
  96  |   await page.screenshot({ path: info.outputPath('action-authority.png') });
  97  |   await info.attach('source-authority', { body: Buffer.from(JSON.stringify({ availability: source.availability, reason: source.reason,
  98  |     missingReadScopes: source.missingReadScopes, sourceWritePerformed: false })), contentType: 'application/json' });
  99  | });
  100 | 
  101 | test('live anonymous denial returns no protected issue information', async ({ request }) => {
  102 |   const response = await request.get('/api/issues/' + repository + '/' + issue, { maxRedirects: 0 });
  103 |   expect([401, 403]).toContain(response.status());
  104 |   expect(await response.text()).not.toContain('"issue"');
  105 | });
  106 | 
  107 | test('live ordinary comment is confirmed by its source identity without continuation', async ({ signedPage: page }, info) => {
  108 |   test.skip(process.env.LCC_E2E_ALLOW_COMMENT !== 'true', 'Actual comment publication requires explicit opt-in on the selected issue.');
  109 |   const operations = [];
  110 |   page.on('request', request => {
  111 |     if (new URL(request.url()).pathname === controlsPath && request.method() === 'POST') operations.push(request.postDataJSON()?.operation);
  112 |   });
  113 |   const source = await (await page.request.get(controlsPath)).json();
  114 |   expect(source.availability, 'Actual source preflight is required; unavailable authority is not a successful comment test.').toBe('available');
  115 |   expect(source.facts?.actions?.comment?.eligible).toBe(true);
  116 |   expect(source.submissionAvailable).toBe(true);
  117 |   await test.step('Open the issue and wait for current comment authority', async () => {
  118 |     await page.goto(issuePath, { waitUntil: 'domcontentloaded' });
  119 |     await expect(page.getByRole('button', { name: 'Review comment', exact: true })).toBeEnabled();
  120 |   });
  121 |   const previous = await test.step('Recover the existing journal before preparing another action', async () => {
  122 |     const recovered = page.waitForResponse(response => response.url().endsWith(controlsPath) && response.request().method() === 'POST'
  123 |       && response.request().postDataJSON()?.operation === 'receipt');
  124 |     await page.getByRole('button', { name: 'Recover previous action', exact: true }).click();
  125 |     const previous = await (await recovered).json();
  126 |     expect(previous.availability).toBe('available');
  127 |     if (previous.receipt?.state !== 'comment-published') expect(['claimed', 'uncertain']).not.toContain(previous.journalState);
  128 |     return previous;
  129 |   });
  130 |   const confirmPrepared = process.env.LCC_E2E_CONFIRM_PREPARED === 'true';
  131 |   if (confirmPrepared) {
  132 |     expect(previous.journalState).toBe('prepared');
  133 |     expect(previous.intent?.action).toBe('comment');
  134 |     expect(previous.intent?.actorId).toBe(source.facts.actor.id);
  135 |     expect(previous.intent?.repository?.name).toBe(repository.toLowerCase());
  136 |     expect(previous.intent?.issue?.number).toBe(issue);
  137 |     expect(previous.intent?.scope).toBe('comment-only');
  138 |     expect(previous.intent?.body).toMatch(/^Lighthouse Control Center E2E: ordinary comment confirmation \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z\. This action requests no continuation\.$/);
  139 |   }
  140 |   const body = confirmPrepared ? previous.intent.body
  141 |     : 'Lighthouse Control Center E2E: ordinary comment confirmation ' + new Date().toISOString() + '. This action requests no continuation.';
  142 |   const confirmation = page.getByRole('region', { name: 'Action confirmation', exact: true });
  143 |   await test.step('Prepare an ordinary comment without dispatching continuation', async () => {
  144 |     if (!confirmPrepared) {
  145 |       await page.getByLabel('Your comment or answer').fill(body);
  146 |       const prepared = page.waitForResponse(response => new URL(response.url()).pathname === controlsPath
  147 |         && response.request().method() === 'POST' && response.request().postDataJSON()?.operation === 'prepare', { timeout: 45000 });
  148 |       await page.getByRole('button', { name: 'Review comment', exact: true }).click();
  149 |       const preparation = await (await prepared).json();
  150 |       expect(preparation.availability, preparation.reason ?? 'Current preparation must be verified.').toBe('available');
  151 |       expect(preparation.journalState).toBe('prepared');
  152 |       expect(preparation.intent?.body).toBe(body);
  153 |     }
  154 |     await expect(confirmation).toContainText('does not resume work');
  155 |     await expect(confirmation).toContainText(body);
  156 |     await expect(page.getByRole('button', { name: 'Confirm and send', exact: true })).toBeEnabled();
  157 |   });
  158 |   const result = await test.step('Send once and inspect the actual source receipt', async () => {
  159 |     const submitted = page.waitForResponse(response => response.url().endsWith(controlsPath) && response.request().method() === 'POST'
  160 |       && response.request().postDataJSON()?.operation === 'submit', { timeout: 45000 });
  161 |     await page.getByRole('button', { name: 'Confirm and send', exact: true }).click();
  162 |     return (await submitted).json();
  163 |   });
  164 |   expect(result.receipt?.state).toBe('comment-published');
  165 |   expect(result.intent?.action).toBe('comment');
  166 |   expect(result.receipt?.questionResolved).toBe(false);
  167 |   expect(operations.filter(value => value === 'submit')).toHaveLength(1);
  168 |   expect(operations.filter(value => value === 'prepare')).toHaveLength(confirmPrepared ? 0 : 1);
  169 |   await expect(confirmation).toContainText('GitHub confirmed that the comment was published.');
  170 |   await expect(page.getByRole('button', { name: 'Confirm and send', exact: true })).toHaveCount(0);
  171 |   await confirmation.screenshot({ path: info.outputPath('confirmed-comment.png') });
  172 |   await page.getByRole('button', { name: 'Refresh source', exact: true }).click();
  173 |   await expect(page.locator('#issue-comments')).toContainText(body);
  174 |   await info.attach('confirmed-source-comment', { body: Buffer.from(JSON.stringify({ commentId: result.receipt.commentId,
  175 |     source: result.receipt.source, actingUserId: result.actingUserId, questionResolved: false, sourceWritePerformed: true,
  176 |     prepareOrSubmitRequests: operations.filter(value => ['prepare', 'submit'].includes(value)).length })), contentType: 'application/json' });
  177 |   await page.locator('#source-comment-' + result.receipt.commentId).screenshot({ path: info.outputPath('source-comment.png') });
  178 | });
  179 | 
  180 | test('live ordinary comment recovery confirms the existing source result without resending', async ({ signedPage: page }, info) => {
  181 |   const expectedId = Number(process.env.LCC_E2E_RECOVER_COMMENT_ID);
```